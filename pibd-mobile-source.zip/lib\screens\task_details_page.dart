import 'package:flutter/material.dart';

import '../services/api_service.dart';

class TaskDetailsPage extends StatefulWidget {
  final int assignmentId;
  const TaskDetailsPage({super.key, required this.assignmentId});

  @override
  State<TaskDetailsPage> createState() => _TaskDetailsPageState();
}

class _TaskDetailsPageState extends State<TaskDetailsPage> {
  final apiService = ApiService();
  Map<String, dynamic>? assignment;
  bool loading = true, updating = false;
  String? error;
  int? remainingDays;
  static const maroon = Color(0xff8B1E24);
  static const cream = Color(0xffF7F4F2);

  @override
  void initState() {
    super.initState();
    loadTask();
  }

  Future<void> loadTask() async {
    setState(() {
      loading = true;
      error = null;
    });
    try {
      final result = await apiService.getTaskDetails(widget.assignmentId);
      if (!mounted) return;
      setState(() {
        assignment = result['task'] as Map<String, dynamic>?;
        loading = false;
      });
      refreshDailyCountdown();
    } catch (e) {
      if (mounted)
        setState(() {
          error = e.toString().replaceFirst('Exception: ', '');
          loading = false;
        });
    }
  }

  Future<void> updateStatus(String status) async {
    setState(() => updating = true);
    try {
      final result = await apiService.updateTaskStatus(
        widget.assignmentId,
        status,
      );
      if (!mounted) return;
      setState(() {
        assignment = result['task'] as Map<String, dynamic>?;
        updating = false;
      });
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Task status updated successfully.')),
      );
    } catch (e) {
      if (mounted) {
        setState(() => updating = false);
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(e.toString().replaceFirst('Exception: ', ''))),
        );
      }
    }
  }

  String date(dynamic value) {
    final d = DateTime.tryParse(value?.toString() ?? '');
    if (d == null) return '-';
    const m = [
      'Jan',
      'Feb',
      'Mar',
      'Apr',
      'May',
      'Jun',
      'Jul',
      'Aug',
      'Sep',
      'Oct',
      'Nov',
      'Dec',
    ];
    return '${d.day.toString().padLeft(2, '0')} ${m[d.month - 1]} ${d.year}';
  }

  Color priorityColor(String? p) => p == 'Urgent'
      ? Colors.red
      : p == 'High'
      ? Colors.orange
      : p == 'Medium'
      ? Colors.blue
      : Colors.green;

  void refreshDailyCountdown() {
    final task = assignment?['task'] as Map<String, dynamic>?;
    final deadline = DateTime.tryParse(task?['deadline']?.toString() ?? '');
    final status = assignment?['status']?.toString();
    if (!mounted || deadline == null || status == 'Completed') return;
    final today = DateTime.now();
    final todayDate = DateTime(today.year, today.month, today.day);
    final deadlineDate = DateTime(deadline.year, deadline.month, deadline.day);
    setState(
      () => remainingDays = deadlineDate.difference(todayDate).inDays + 1,
    );
  }

  String countdownText() {
    if (assignment?['status'] == 'Completed') return 'Completed';
    if (remainingDays == null || remainingDays! <= 0) return 'Due time';
    return remainingDays == 1 ? '1 day left' : '${remainingDays} days left';
  }

  @override
  Widget build(BuildContext context) {
    final task = assignment?['task'] as Map<String, dynamic>?;
    return Scaffold(
      backgroundColor: cream,
      appBar: AppBar(
        centerTitle: true,
        title: const Text(
          'Task Details',
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        actions: const [
          Padding(
            padding: EdgeInsets.only(right: 14),
            child: Icon(Icons.assignment_rounded),
          ),
        ],
        backgroundColor: maroon,
        foregroundColor: Colors.white,
        elevation: 0,
      ),
      body: loading
          ? const Center(child: CircularProgressIndicator(color: maroon))
          : error != null
          ? _error()
          : task == null
          ? const Center(child: Text('Task not found.'))
          : RefreshIndicator(
              onRefresh: loadTask,
              child: ListView(
                padding: const EdgeInsets.all(16),
                children: [
                  _hero(task),
                  const SizedBox(height: 16),
                  _meta(task),
                  const SizedBox(height: 16),
                  _countdownCard(task),
                  const SizedBox(height: 16),
                  _descriptionCard(task),
                  const SizedBox(height: 16),
                  _statusCard(),
                  const SizedBox(height: 16),
                  _attachments(task),
                ],
              ),
            ),
    );
  }

  Widget _error() => Center(
    child: Padding(
      padding: const EdgeInsets.all(24),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Icon(Icons.cloud_off, size: 56, color: maroon),
          const SizedBox(height: 12),
          Text(error!, textAlign: TextAlign.center),
          const SizedBox(height: 16),
          FilledButton(onPressed: loadTask, child: const Text('Try Again')),
        ],
      ),
    ),
  );

  Widget _hero(Map<String, dynamic> task) => Container(
    padding: const EdgeInsets.all(22),
    decoration: BoxDecoration(
      borderRadius: BorderRadius.circular(24),
      gradient: const LinearGradient(colors: [maroon, Color(0xffB84A50)]),
      boxShadow: [
        BoxShadow(
          color: maroon.withOpacity(.22),
          blurRadius: 16,
          offset: Offset(0, 8),
        ),
      ],
    ),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Icon(Icons.assignment_rounded, color: Colors.white, size: 34),
        const SizedBox(height: 14),
        Text(
          task['title'] ?? 'Untitled task',
          style: const TextStyle(
            color: Colors.white,
            fontSize: 25,
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 8),
        Text(
          'Review the task requirements and keep your progress updated.',
          style: TextStyle(color: Colors.white.withOpacity(.85), height: 1.4),
        ),
      ],
    ),
  );

  Widget _meta(Map<String, dynamic> task) => Card(
    elevation: 0,
    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
    child: Padding(
      padding: const EdgeInsets.all(16),
      child: Row(
        children: [
          Expanded(
            child: _metric(
              Icons.flag_outlined,
              'Priority',
              task['priority'] ?? '-',
              priorityColor(task['priority']?.toString()),
            ),
          ),
          Expanded(
            child: _metric(
              Icons.event_outlined,
              'Deadline',
              date(task['deadline']),
              maroon,
            ),
          ),
          Expanded(
            child: _metric(
              Icons.track_changes,
              'Status',
              assignment?['status'] ?? 'Pending',
              maroon,
            ),
          ),
        ],
      ),
    ),
  );

  Widget _countdownCard(Map<String, dynamic> task) {
    final completed = assignment?['status'] == 'Completed';
    final overdue =
        !completed && (remainingDays == null || remainingDays! <= 0);
    final color = completed
        ? Colors.green
        : overdue
        ? Colors.red
        : maroon;
    return Card(
      elevation: 0,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(13),
              decoration: BoxDecoration(
                color: color.withOpacity(.1),
                shape: BoxShape.circle,
              ),
              child: Icon(
                completed
                    ? Icons.check_circle
                    : overdue
                    ? Icons.warning_amber_rounded
                    : Icons.timer_outlined,
                color: color,
                size: 30,
              ),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    completed
                        ? 'Task completed'
                        : overdue
                        ? 'Deadline passed'
                        : 'Time remaining',
                    style: const TextStyle(color: Colors.grey, fontSize: 12),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    countdownText(),
                    style: TextStyle(
                      color: color,
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  if (!completed && !overdue)
                    Text(
                      'Deadline: ${date(task['deadline'])}',
                      style: const TextStyle(fontSize: 12, color: Colors.grey),
                    ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _descriptionCard(Map<String, dynamic> task) {
    final description = task['description']?.toString().trim();

    return TweenAnimationBuilder<double>(
      tween: Tween(begin: 0.0, end: 1.0),
      duration: const Duration(milliseconds: 550),
      curve: Curves.easeOutCubic,
      builder: (context, value, child) {
        return Opacity(
          opacity: value,
          child: Transform.translate(
            offset: Offset(0, 14 * (1 - value)),
            child: child,
          ),
        );
      },
      child: Container(
        decoration: BoxDecoration(
          color: const Color(0xfffffbef),
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: const Color(0xffeadfbf)),
          boxShadow: const [
            BoxShadow(
              color: Color(0x12000000),
              blurRadius: 12,
              offset: Offset(0, 5),
            ),
          ],
        ),
        padding: const EdgeInsets.fromLTRB(20, 18, 20, 20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(9),
                  decoration: BoxDecoration(
                    color: const Color(0xffffedb8),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: const Icon(
                    Icons.sticky_note_2_outlined,
                    color: Color(0xff8B1E24),
                  ),
                ),
                const SizedBox(width: 11),
                const Text(
                  'Task Note',
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: Color(0xff5f4b20),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            Text(
              description?.isNotEmpty == true
                  ? description!
                  : 'No description available.',
              style: const TextStyle(
                height: 1.65,
                fontSize: 15,
                color: Color(0xff4b4538),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _metric(IconData icon, String label, dynamic value, Color color) =>
      Column(
        children: [
          Icon(icon, color: color),
          const SizedBox(height: 7),
          Text(label, style: const TextStyle(fontSize: 11, color: Colors.grey)),
          const SizedBox(height: 3),
          Text(
            value.toString(),
            textAlign: TextAlign.center,
            style: TextStyle(
              fontWeight: FontWeight.bold,
              color: color,
              fontSize: 13,
            ),
          ),
        ],
      );

  Widget _card(IconData icon, String title, Widget child) => Card(
    elevation: 0,
    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
    child: Padding(
      padding: const EdgeInsets.all(18),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(icon, color: maroon),
              const SizedBox(width: 10),
              Text(
                title,
                style: const TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),
          child,
        ],
      ),
    ),
  );

  Widget _statusCard() => _card(
    Icons.sync_outlined,
    'Update Progress',
    Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Current status: ${assignment?['status'] ?? 'Pending'}',
          style: const TextStyle(fontWeight: FontWeight.w600),
        ),
        const SizedBox(height: 14),
        Row(
          children: [
            Expanded(
              child: OutlinedButton(
                onPressed: updating ? null : () => updateStatus('In Progress'),
                child: const Text('In Progress'),
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: FilledButton(
                onPressed: updating ? null : () => updateStatus('Completed'),
                style: FilledButton.styleFrom(backgroundColor: maroon),
                child: const Text('Completed'),
              ),
            ),
          ],
        ),
      ],
    ),
  );

  Widget _attachments(Map<String, dynamic> task) {
    final files = task['attachments'] as List? ?? [];
    return _card(
      Icons.attach_file,
      'Attachments',
      files.isEmpty
          ? const Text('No attachments available.')
          : Column(
              children: files.map((raw) {
                final f = raw as Map<String, dynamic>;
                final name = f['original_name']?.toString() ?? 'Attachment';
                return ListTile(
                  contentPadding: EdgeInsets.zero,
                  leading: const CircleAvatar(
                    backgroundColor: Color(0xffF1DADC),
                    child: Icon(
                      Icons.insert_drive_file_outlined,
                      color: maroon,
                    ),
                  ),
                  title: Text(
                    name,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                  ),
                  subtitle: Text(f['mime_type']?.toString() ?? 'File'),
                  trailing: IconButton(
                    icon: const Icon(Icons.download_outlined, color: maroon),
                    onPressed: () async {
                      try {
                        await apiService.downloadTaskAttachment(
                          widget.assignmentId,
                          f['id'] as int,
                          name,
                        );
                        if (mounted)
                          ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(
                              content: Text('Attachment downloaded.'),
                            ),
                          );
                      } catch (e) {
                        if (mounted)
                          ScaffoldMessenger.of(context).showSnackBar(
                            SnackBar(
                              content: Text(
                                e.toString().replaceFirst('Exception: ', ''),
                              ),
                            ),
                          );
                      }
                    },
                  ),
                );
              }).toList(),
            ),
    );
  }
}
