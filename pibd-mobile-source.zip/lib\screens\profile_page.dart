import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';

import '../services/api_service.dart';

class ProfilePage extends StatefulWidget {
  final Map<String, dynamic>? user;
  const ProfilePage({super.key, this.user});

  @override
  State<ProfilePage> createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  final apiService = ApiService();
  final oldPassword = TextEditingController();
  final newPassword = TextEditingController();
  final confirmPassword = TextEditingController();
  Map<String, dynamic>? user;
  bool loading = true, saving = false, uploading = false;
  bool hideOld = true, hideNew = true, hideConfirm = true;

  static const maroon = Color(0xff8B1E24);
  static const cream = Color(0xffF7F4F2);

  @override
  void initState() {
    super.initState();
    loadProfile();
  }

  Future<void> loadProfile() async {
    try {
      final result = await apiService.getMe();
      if (!mounted) return;
      setState(() {
        user = result['user'] as Map<String, dynamic>?;
        loading = false;
      });
    } catch (_) {
      if (mounted) setState(() => loading = false);
    }
  }

  Future<void> pickAvatar() async {
    final image = await ImagePicker().pickImage(
      source: ImageSource.gallery,
      imageQuality: 85,
      maxWidth: 1200,
    );
    if (image == null) return;
    setState(() => uploading = true);
    try {
      final result = await apiService.uploadAvatar(image);
      if (!mounted) return;
      setState(() => user = result['user'] as Map<String, dynamic>?);
      message('Profile image updated successfully.');
    } catch (e) {
      message(e.toString().replaceFirst('Exception: ', ''));
    } finally {
      if (mounted) setState(() => uploading = false);
    }
  }

  Future<void> changePassword() async {
    if (newPassword.text.length < 8) {
      message('New password must be at least 8 characters.');
      return;
    }
    if (newPassword.text != confirmPassword.text) {
      message('New passwords do not match.');
      return;
    }
    setState(() => saving = true);
    try {
      await apiService.changePassword(
        currentPassword: oldPassword.text,
        newPassword: newPassword.text,
        confirmation: confirmPassword.text,
      );
      oldPassword.clear();
      newPassword.clear();
      confirmPassword.clear();
      message('Password changed successfully.');
    } catch (e) {
      message(e.toString().replaceFirst('Exception: ', ''));
    } finally {
      if (mounted) setState(() => saving = false);
    }
  }

  void message(String text) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text)));
  }

  Future<void> logout() async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Logout?'),
        content: const Text('Are you sure you want to logout?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('Logout'),
          ),
        ],
      ),
    );
    if (ok != true) return;
    await apiService.logout();
    if (mounted) {
      Navigator.of(context).pushNamedAndRemoveUntil('/login', (_) => false);
    }
  }

  @override
  void dispose() {
    oldPassword.dispose();
    newPassword.dispose();
    confirmPassword.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final data = user ?? widget.user ?? <String, dynamic>{};
    final avatar = data['avatar_url']?.toString() ?? '';
    final name = data['name']?.toString() ?? 'Employee';
    return Scaffold(
      backgroundColor: cream,
      appBar: AppBar(
        title: const Text(
          'My Profile',
          style: TextStyle(fontWeight: FontWeight.w700),
        ),
        backgroundColor: maroon,
        foregroundColor: Colors.white,
        elevation: 0,
      ),
      body: loading
          ? const Center(child: CircularProgressIndicator(color: maroon))
          : RefreshIndicator(
              onRefresh: loadProfile,
              child: ListView(
                padding: const EdgeInsets.fromLTRB(16, 20, 16, 32),
                children: [
                  _profileHero(data, avatar, name),
                  const SizedBox(height: 18),
                  _sectionCard(
                    icon: Icons.badge_outlined,
                    title: 'Personal Information',
                    child: Column(
                      children: [
                        _info(Icons.person_outline, 'Full Name', data['name']),
                        _info(
                          Icons.badge_outlined,
                          'Employee ID',
                          data['employee_id'],
                        ),
                        _info(
                          Icons.work_outline,
                          'Designation',
                          data['designation'],
                        ),
                        _info(
                          Icons.email_outlined,
                          'Email address',
                          data['email'],
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 18),
                  _sectionCard(
                    icon: Icons.lock_outline,
                    title: 'Security',
                    subtitle: 'Update your password regularly to keep your account safe.',
                    child: Column(
                      children: [
                        _password(
                          oldPassword,
                          'Current password',
                          hideOld,
                          () => setState(() => hideOld = !hideOld),
                        ),
                        _password(
                          newPassword,
                          'New password',
                          hideNew,
                          () => setState(() => hideNew = !hideNew),
                        ),
                        _password(
                          confirmPassword,
                          'Confirm new password',
                          hideConfirm,
                          () => setState(() => hideConfirm = !hideConfirm),
                        ),
                        SizedBox(
                          width: double.infinity,
                          child: FilledButton.icon(
                            onPressed: saving ? null : changePassword,
                            icon: const Icon(Icons.check_circle_outline),
                            label: Text(
                              saving ? 'Saving...' : 'Update Password',
                            ),
                            style: FilledButton.styleFrom(
                              backgroundColor: maroon,
                              padding: const EdgeInsets.symmetric(vertical: 14),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 18),
                  OutlinedButton.icon(
                    onPressed: logout,
                    icon: const Icon(Icons.logout, color: maroon),
                    label: const Text(
                      'Logout',
                      style: TextStyle(color: maroon),
                    ),
                    style: OutlinedButton.styleFrom(
                      side: const BorderSide(color: maroon),
                      padding: const EdgeInsets.symmetric(vertical: 14),
                    ),
                  ),
                ],
              ),
            ),
    );
  }

  Widget _profileHero(Map<String, dynamic> data, String avatar, String name) =>
      Container(
        padding: const EdgeInsets.all(22),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(24),
          gradient: const LinearGradient(
            colors: [maroon, Color(0xffB84A50)],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          boxShadow: [
            BoxShadow(
              color: maroon.withValues(alpha: .25),
              blurRadius: 16,
              offset: const Offset(0, 8),
            ),
          ],
        ),
        child: Column(
          children: [
            CircleAvatar(
              radius: 48,
              backgroundColor: Colors.white,
              backgroundImage: avatar.isNotEmpty ? NetworkImage(avatar) : null,
              child: avatar.isEmpty
                  ? const Icon(Icons.person, size: 54, color: maroon)
                  : null,
            ),
            const SizedBox(height: 12),
            Text(
              name,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 22,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 4),
            Text(
              data['designation']?.toString() ?? 'Employee',
              style: const TextStyle(color: Colors.white70),
            ),
            const SizedBox(height: 16),
            OutlinedButton.icon(
              onPressed: uploading ? null : pickAvatar,
              icon: uploading
                  ? const SizedBox(
                      width: 16,
                      height: 16,
                      child: CircularProgressIndicator(
                        strokeWidth: 2,
                        color: Colors.white,
                      ),
                    )
                  : const Icon(Icons.camera_alt_outlined),
              label: Text(uploading ? 'Uploading...' : 'Change Profile Photo'),
              style: OutlinedButton.styleFrom(
                foregroundColor: Colors.white,
                side: const BorderSide(color: Colors.white70),
              ),
            ),
          ],
        ),
      );

  Widget _sectionCard({
    required IconData icon,
    required String title,
    String? subtitle,
    required Widget child,
  }) => Card(
    elevation: 0,
    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
    child: Padding(
      padding: const EdgeInsets.all(18),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(icon, color: maroon),
              const SizedBox(width: 10),
              Text(
                title,
                style: const TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ],
          ),
          if (subtitle != null) ...[
            const SizedBox(height: 6),
            Text(subtitle, style: const TextStyle(color: Colors.grey)),
          ],
          const SizedBox(height: 14),
          child,
        ],
      ),
    ),
  );

  Widget _info(IconData icon, String label, dynamic value) => ListTile(
    contentPadding: EdgeInsets.zero,
    leading: Icon(icon, color: maroon),
    title: Text(
      label,
      style: const TextStyle(fontSize: 12, color: Colors.grey),
    ),
    subtitle: Text(
      value?.toString().isNotEmpty == true ? value.toString() : '-',
      style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
    ),
  );

  Widget _password(
    TextEditingController c,
    String label,
    bool hidden,
    VoidCallback toggle,
  ) => Padding(
    padding: const EdgeInsets.only(bottom: 12),
    child: TextField(
      controller: c,
      obscureText: hidden,
      decoration: InputDecoration(
        labelText: label,
        prefixIcon: const Icon(Icons.lock_outline),
        suffixIcon: IconButton(
          onPressed: toggle,
          icon: Icon(hidden ? Icons.visibility_off : Icons.visibility),
        ),
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
      ),
    ),
  );
}
