import 'package:flutter/material.dart';

import '../services/api_service.dart';
import 'attendance_page.dart';
import 'leave_page.dart';
import 'task_details_page.dart';
import 'profile_page.dart';

String _formatDashboardDate(dynamic value) {
  if (value == null || value.toString().isEmpty) {
    return '-';
  }

  final parsed = DateTime.tryParse(value.toString());

  if (parsed == null) {
    return value.toString();
  }

  const months = [
    'Jan',
    'Feb',
    'Mar',
    'Apr',
    'May',
    'Jun',
    'Jul',
    'Aug',
    'Sep',
    'Oct',
    'Nov',
    'Dec',
  ];

  return '${parsed.day.toString().padLeft(2, '0')} '
      '${months[parsed.month - 1]} ${parsed.year}';
}

class DashboardPage extends StatefulWidget {
  final Map<String, dynamic>? user;

  const DashboardPage({super.key, this.user});

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage> {
  final apiService = ApiService();

  bool loading = true;
  String? errorMessage;
  Map<String, dynamic> dashboard = {};

  @override
  void initState() {
    super.initState();
    loadDashboard();
  }

  Future<void> loadDashboard() async {
    try {
      final data = await apiService.getDashboard();

      if (!mounted) return;

      setState(() {
        dashboard = data;
        loading = false;
      });
    } catch (error) {
      if (!mounted) return;

      setState(() {
        errorMessage = error.toString().replaceFirst('Exception: ', '');
        loading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final employeeId =
        dashboard['employee_id'] ?? widget.user?['employee_id'] ?? '---';

    final tasks = dashboard['tasks'] as List? ?? [];
    final leaves = dashboard['leave_requests'] as List? ?? [];

    void openAttendance() {
      Navigator.push(
        context,
        MaterialPageRoute(builder: (_) => const AttendancePage()),
      );
    }

    void openLeave() {
      Navigator.push(
        context,
        MaterialPageRoute(builder: (_) => const LeavePage()),
      );
    }

    return Scaffold(
      backgroundColor: const Color(0xffF7F4F2),
      appBar: AppBar(
        title: const Text(
          'PIBD Employee Portal',
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        backgroundColor: const Color(0xff8B1E24),
        foregroundColor: Colors.white,
        actions: [
          IconButton(
            tooltip: 'My Profile',
            icon: const CircleAvatar(
              radius: 17,
              backgroundColor: Colors.white,
              child: Icon(Icons.person, size: 25, color: Color(0xff8B1E24)),
            ),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => ProfilePage(user: widget.user),
                ),
              );
            },
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        backgroundColor: const Color(0xff8B1E24),
        foregroundColor: Colors.white,
        onPressed: openAttendance,
        icon: const Icon(Icons.calendar_today),
        label: const Text('Attendance'),
      ),
      body: loading
          ? const Center(child: CircularProgressIndicator())
          : errorMessage != null
          ? Center(
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Text(
                  errorMessage!,
                  textAlign: TextAlign.center,
                  style: const TextStyle(color: Colors.red),
                ),
              ),
            )
          : RefreshIndicator(
              onRefresh: loadDashboard,
              child: ListView(
                padding: const EdgeInsets.all(20),
                children: [
                  Text(
                    'Welcome back',
                    style: Theme.of(context).textTheme.headlineSmall
                        ?.copyWith(fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 5),
                  Text(
                    'Employee ID: $employeeId',
                    style: const TextStyle(color: Colors.black54),
                  ),
                  const SizedBox(height: 24),
                  Row(
                    children: [
                      Expanded(
                        child: _summaryCard(
                          icon: Icons.task_alt,
                          title: 'Tasks',
                          value: '${tasks.length}',
                          color: Colors.blue,
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: InkWell(
                          borderRadius: BorderRadius.circular(12),
                          onTap: openLeave,
                          child: _summaryCard(
                            icon: Icons.event_note,
                            title: 'Leave',
                            value: '${leaves.length}',
                            color: Colors.orange,
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 28),
                  const Text(
                    'My Tasks',
                    style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 10),
                  if (tasks.isEmpty)
                    _emptyCard('No tasks assigned yet.')
                  else
                    ...tasks.map(
                      (assignment) =>
                          _taskCard(assignment as Map<String, dynamic>),
                    ),
                  const SizedBox(height: 24),
                  const Text(
                    'Leave Requests',
                    style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 10),
                  if (leaves.isEmpty)
                    _emptyCard('No leave requests yet.')
                  else
                    ...leaves.map(
                      (leave) => _leaveCard(leave as Map<String, dynamic>),
                    ),
                ],
              ),
            ),
    );
  }

  Widget _summaryCard({
    required IconData icon,
    required String title,
    required String value,
    required Color color,
  }) {
    return Card(
      elevation: 0,
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Column(
          children: [
            Icon(icon, color: color, size: 32),
            const SizedBox(height: 8),
            Text(
              value,
              style: const TextStyle(fontSize: 26, fontWeight: FontWeight.bold),
            ),
            Text(title, style: const TextStyle(color: Colors.black54)),
          ],
        ),
      ),
    );
  }

  Widget _taskCard(Map<String, dynamic> assignment) {
    final task = assignment['task'] as Map<String, dynamic>?;

    return Card(
      child: ListTile(
        leading: const CircleAvatar(
          backgroundColor: Color(0xffE9D5D7),
          child: Icon(Icons.assignment, color: Color(0xff8B1E24)),
        ),
        title: Text(task?['title'] ?? 'Untitled task'),
        subtitle: Text('Status: ${assignment['status'] ?? 'Pending'}'),
        trailing: const Icon(Icons.chevron_right),
        onTap: () {
          final assignmentId = assignment['assignment_id'];

          if (assignmentId is int) {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => TaskDetailsPage(assignmentId: assignmentId),
              ),
            );
          }
        },
      ),
    );
  }

  Widget _leaveCard(Map<String, dynamic> leave) {
    return Card(
      child: ListTile(
        leading: const CircleAvatar(
          backgroundColor: Color(0xffFFF0D2),
          child: Icon(Icons.event, color: Colors.orange),
        ),
        title: Text(leave['leave_type'] ?? 'Leave'),
        subtitle: Text(
          '${_formatDashboardDate(leave['start_date'])} - '
          '${_formatDashboardDate(leave['end_date'])}'
          '\nStatus: ${leave['status'] ?? 'Pending'}',
        ),
      ),
    );
  }

  Widget _emptyCard(String message) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Text(message, style: const TextStyle(color: Colors.black54)),
      ),
    );
  }
}
